# J.A.R.V.I.S. — Android Personal Assistant

An Iron Man-themed personal AI assistant for Android, powered by Claude (claude-sonnet-4-20250514).

## Features
- Chat with Jarvis powered by Anthropic's Claude API
- Voice input via Android Speech Recognition
- Task manager with Room database (persistent storage)
- Iron Man dark blue theme throughout
- Quick action chips for common commands

## Setup Instructions

### 1. Get your Anthropic API Key
- Visit https://console.anthropic.com
- Create an account and generate an API key

### 2. Add your API Key
Open `app/build.gradle` and replace:
```
buildConfigField "String", "ANTHROPIC_API_KEY", '"YOUR_ANTHROPIC_API_KEY_HERE"'
```
with your actual key:
```
buildConfigField "String", "ANTHROPIC_API_KEY", '"sk-ant-api03-..."'
```

### 3. Open in Android Studio
- Open Android Studio (Hedgehog or newer)
- File > Open > select the `JarvisApp` folder
- Wait for Gradle sync to complete
- Connect an Android device or start an emulator (API 26+)
- Press Run (green play button)

## Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- Android device or emulator running API 26 (Android 8.0) or higher
- Internet connection for AI chat
- Microphone permission for voice input

## Project Structure
```
JarvisApp/
├── app/src/main/
│   ├── java/com/jarvis/assistant/
│   │   ├── MainActivity.kt          # App entry, tabs setup
│   │   ├── ChatFragment.kt          # Chat UI + voice input
│   │   ├── TasksFragment.kt         # Task manager
│   │   ├── ChatAdapter.kt           # Chat messages adapter
│   │   ├── TasksAdapter.kt          # Tasks list adapter
│   │   ├── JarvisApiClient.kt       # Anthropic API calls
│   │   └── TaskDatabase.kt          # Room DB for tasks
│   ├── res/
│   │   ├── layout/                  # XML layouts
│   │   ├── drawable/                # Icons & backgrounds
│   │   └── values/                  # Colors, strings, themes
│   └── AndroidManifest.xml
├── build.gradle
└── settings.gradle
```

## Security Note
Do NOT commit your API key to version control. For production apps, store the key securely using a backend proxy or Android's EncryptedSharedPreferences.
