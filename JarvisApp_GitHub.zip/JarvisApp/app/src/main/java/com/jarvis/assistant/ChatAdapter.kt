package com.jarvis.assistant

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class UiMessage(val content: String, val isUser: Boolean)

class ChatAdapter(private val messages: MutableList<UiMessage> = mutableListOf()) :
    RecyclerView.Adapter<ChatAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val container: ViewGroup = view.findViewById(R.id.messageContainer)
        val avatar: TextView = view.findViewById(R.id.avatarText)
        val bubble: TextView = view.findViewById(R.id.messageText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_message, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val msg = messages[position]

        if (msg.isUser) {
            holder.container.layoutDirection = View.LAYOUT_DIRECTION_RTL
            holder.avatar.text = "U"
            holder.avatar.setTextColor(holder.avatar.context.getColor(R.color.white))
            holder.avatar.background = holder.avatar.context.getDrawable(R.drawable.bubble_user)
            holder.bubble.background = holder.bubble.context.getDrawable(R.drawable.bubble_user)
            holder.bubble.setTextColor(holder.bubble.context.getColor(R.color.text_primary))
        } else {
            holder.container.layoutDirection = View.LAYOUT_DIRECTION_LTR
            holder.avatar.text = "J"
            holder.avatar.setTextColor(holder.avatar.context.getColor(R.color.jarvis_blue_light))
            holder.avatar.background = holder.avatar.context.getDrawable(R.drawable.avatar_bg)
            holder.bubble.background = holder.bubble.context.getDrawable(R.drawable.bubble_jarvis)
            holder.bubble.setTextColor(holder.bubble.context.getColor(R.color.jarvis_blue_pale))
        }

        holder.bubble.text = msg.content
    }

    override fun getItemCount() = messages.size

    fun addMessage(msg: UiMessage) {
        messages.add(msg)
        notifyItemInserted(messages.size - 1)
    }

    fun removeLastIfTyping() {
        if (messages.isNotEmpty() && messages.last().content == "...") {
            messages.removeAt(messages.size - 1)
            notifyItemRemoved(messages.size)
        }
    }
}
