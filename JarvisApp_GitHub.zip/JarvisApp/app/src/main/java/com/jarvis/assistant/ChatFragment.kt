package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.jarvis.assistant.databinding.FragmentChatBinding
import kotlinx.coroutines.launch

class ChatFragment : Fragment() {

    private var _binding: FragmentChatBinding? = null
    private val binding get() = _binding!!

    private lateinit var chatAdapter: ChatAdapter
    private val conversationHistory = mutableListOf<ChatMessage>()

    private val quickActions = listOf(
        "What can you do?",
        "Tell me a fun fact",
        "Motivate me",
        "What time is it?",
        "Help me plan my day",
        "Translate to Tamil"
    )

    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                binding.messageInput.setText(spokenText)
                sendMessage()
            }
        }
    }

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startVoiceInput()
        else Toast.makeText(context, "Microphone permission required for voice input.", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentChatBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupQuickActions()
        setupInputActions()
        addJarvisMessage(getString(R.string.jarvis_greeting))
    }

    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter()
        val layoutManager = LinearLayoutManager(context).apply { stackFromEnd = true }
        binding.chatRecyclerView.layoutManager = layoutManager
        binding.chatRecyclerView.adapter = chatAdapter
    }

    private fun setupQuickActions() {
        quickActions.forEach { action ->
            val chip = Button(requireContext(), null, 0, R.style.Widget_MaterialComponents_Button_OutlinedButton).apply {
                text = action
                textSize = 12f
                background = requireContext().getDrawable(R.drawable.chip_bg)
                setTextColor(requireContext().getColor(R.color.jarvis_blue_light))
                setPadding(32, 0, 32, 0)
                setOnClickListener {
                    binding.messageInput.setText(action)
                    sendMessage()
                }
            }
            binding.quickActionsContainer.addView(chip)
        }
    }

    private fun setupInputActions() {
        binding.sendButton.setOnClickListener { sendMessage() }

        binding.messageInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else false
        }

        binding.micButton.setOnClickListener {
            when {
                ContextCompat.checkSelfPermission(
                    requireContext(), Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED -> startVoiceInput()
                else -> micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your command, sir…")
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Voice recognition not available on this device.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendMessage() {
        val text = binding.messageInput.text.toString().trim()
        if (text.isEmpty()) return

        binding.messageInput.text?.clear()
        addUserMessage(text)
        conversationHistory.add(ChatMessage("user", text))
        addJarvisMessage("...")

        lifecycleScope.launch {
            val result = JarvisApiClient.sendMessage(conversationHistory)
            chatAdapter.removeLastIfTyping()
            result.onSuccess { reply ->
                conversationHistory.add(ChatMessage("assistant", reply))
                addJarvisMessage(reply)
            }.onFailure {
                addJarvisMessage("Apologies, sir. I'm having trouble connecting to my systems. Please check your API key and internet connection.")
            }
        }
    }

    private fun addJarvisMessage(text: String) {
        chatAdapter.addMessage(UiMessage(text, false))
        binding.chatRecyclerView.scrollToPosition(chatAdapter.itemCount - 1)
    }

    private fun addUserMessage(text: String) {
        chatAdapter.addMessage(UiMessage(text, true))
        binding.chatRecyclerView.scrollToPosition(chatAdapter.itemCount - 1)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
