package com.jarvis.assistant

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.jarvis.assistant.databinding.FragmentTasksBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class TasksFragment : Fragment() {

    private var _binding: FragmentTasksBinding? = null
    private val binding get() = _binding!!

    private lateinit var tasksAdapter: TasksAdapter
    private lateinit var taskDao: TaskDao

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTasksBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        taskDao = AppDatabase.getDatabase(requireContext()).taskDao()

        tasksAdapter = TasksAdapter(
            onChecked = { task, checked ->
                lifecycleScope.launch { taskDao.updateTask(task.copy(isDone = checked)) }
            },
            onDelete = { task ->
                lifecycleScope.launch { taskDao.deleteTask(task) }
            }
        )

        binding.tasksRecyclerView.layoutManager = LinearLayoutManager(context)
        binding.tasksRecyclerView.adapter = tasksAdapter

        lifecycleScope.launch {
            taskDao.getAllTasks().collectLatest { tasks ->
                tasksAdapter.submitList(tasks)
                binding.emptyText.visibility = if (tasks.isEmpty()) View.VISIBLE else View.GONE
                binding.tasksRecyclerView.visibility = if (tasks.isEmpty()) View.GONE else View.VISIBLE
            }
        }

        binding.addTaskButton.setOnClickListener { addTask() }
        binding.taskInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { addTask(); true } else false
        }
    }

    private fun addTask() {
        val text = binding.taskInput.text.toString().trim()
        if (text.isEmpty()) return
        binding.taskInput.text?.clear()
        lifecycleScope.launch {
            taskDao.insertTask(Task(title = text))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
