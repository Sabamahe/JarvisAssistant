package com.jarvis.assistant

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.os.Bundle
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.google.android.material.tabs.TabLayoutMediator
import com.jarvis.assistant.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupViewPager()
        animateArcReactor()
        animateStatusDot()
    }

    private fun setupViewPager() {
        val adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount() = 2
            override fun createFragment(position: Int): Fragment = when (position) {
                0 -> ChatFragment()
                else -> TasksFragment()
            }
        }
        binding.viewPager.adapter = adapter
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> getString(R.string.tab_chat)
                else -> getString(R.string.tab_tasks)
            }
        }.attach()
    }

    private fun animateArcReactor() {
        val pulseAnim = ObjectAnimator.ofFloat(binding.arcInner, View.ALPHA, 1f, 0.4f, 1f)
        pulseAnim.duration = 2000
        pulseAnim.repeatCount = ValueAnimator.INFINITE
        pulseAnim.interpolator = LinearInterpolator()
        pulseAnim.start()
    }

    private fun animateStatusDot() {
        val blinkAnim = ObjectAnimator.ofFloat(binding.statusDot, View.ALPHA, 1f, 0.2f, 1f)
        blinkAnim.duration = 1500
        blinkAnim.repeatCount = ValueAnimator.INFINITE
        blinkAnim.start()
    }
}
