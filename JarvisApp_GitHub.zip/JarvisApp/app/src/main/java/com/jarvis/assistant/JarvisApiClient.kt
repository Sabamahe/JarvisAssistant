package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(val role: String, val content: String)

object JarvisApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val API_URL = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-sonnet-4-20250514"

    private val systemPrompt = """
        You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), the AI assistant from Iron Man.
        You are highly intelligent, slightly formal yet warm, efficient, and occasionally witty.
        You address the user as "sir" or "ma'am".
        You are running as a personal assistant app on Android.
        Keep responses concise and helpful — under 120 words unless more detail is specifically requested.
        Today's date: ${java.text.SimpleDateFormat("EEEE, MMMM d yyyy", java.util.Locale.getDefault()).format(java.util.Date())}.
        Current time: ${java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())}.
    """.trimIndent()

    suspend fun sendMessage(history: List<ChatMessage>): Result<String> = withContext(Dispatchers.IO) {
        try {
            val messagesArray = JSONArray()
            for (msg in history) {
                messagesArray.put(JSONObject().apply {
                    put("role", msg.role)
                    put("content", msg.content)
                })
            }

            val body = JSONObject().apply {
                put("model", MODEL)
                put("max_tokens", 1000)
                put("system", systemPrompt)
                put("messages", messagesArray)
            }.toString()

            val request = Request.Builder()
                .url(API_URL)
                .addHeader("Content-Type", "application/json")
                .addHeader("x-api-key", BuildConfig.ANTHROPIC_API_KEY)
                .addHeader("anthropic-version", "2023-06-01")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val json = JSONObject(responseBody)
                val content = json.getJSONArray("content")
                    .getJSONObject(0)
                    .getString("text")
                Result.success(content)
            } else {
                Result.failure(Exception("API error ${response.code}: $responseBody"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
