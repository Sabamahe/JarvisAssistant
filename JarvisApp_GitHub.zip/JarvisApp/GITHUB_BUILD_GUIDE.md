# How to Build Jarvis APK via GitHub (Free)

Follow these steps exactly — takes about 10 minutes total.

---

## Step 1 — Create a GitHub Account
Go to https://github.com and sign up (free).

---

## Step 2 — Create a New Repository
1. Click the **+** button (top right) → **New repository**
2. Name it: `JarvisAssistant`
3. Set to **Private** (keeps your API key safe)
4. Click **Create repository**

---

## Step 3 — Upload the Project Files
1. On your new repo page, click **uploading an existing file**
2. Extract the `JarvisApp.zip` on your computer
3. Drag and drop the ENTIRE contents of the `JarvisApp` folder into GitHub
4. Scroll down → click **Commit changes**

---

## Step 4 — Add Your Anthropic API Key as a Secret
This keeps your API key hidden and safe — never visible in code.

1. In your repo, go to **Settings** → **Secrets and variables** → **Actions**
2. Click **New repository secret**
3. Name: `ANTHROPIC_API_KEY`
4. Value: your key from https://console.anthropic.com (starts with `sk-ant-...`)
5. Click **Add secret**

---

## Step 5 — Run the Build
1. Go to the **Actions** tab in your repo
2. Click **Build Jarvis APK** in the left sidebar
3. Click **Run workflow** → **Run workflow** (green button)
4. Wait ~5 minutes for the build to complete (green checkmark = success)

---

## Step 6 — Download Your APK
1. Click on the completed workflow run
2. Scroll down to **Artifacts**
3. Click **Jarvis-APK** to download
4. Extract the ZIP → you'll find `app-debug.apk` inside

---

## Step 7 — Install on Your Android Phone
1. Copy `app-debug.apk` to your Android phone
2. On your phone: **Settings → Security → Allow unknown sources** (or "Install unknown apps")
3. Open the APK file on your phone → **Install**
4. Open **J.A.R.V.I.S.** and start chatting!

---

## Troubleshooting
- **Build fails?** Check the Actions log for errors. Most common: API key not set correctly.
- **App crashes?** Make sure your API key is valid and you have internet.
- **"Unknown sources" not showing?** On Android 8+, go to Settings → Apps → Special app access → Install unknown apps → select your file manager.

---

## Every Future Update
After any code change, just push to GitHub and the APK rebuilds automatically!
